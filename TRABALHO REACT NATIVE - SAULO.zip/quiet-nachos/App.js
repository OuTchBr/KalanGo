import * as React from 'react';
import { Text, View, StyleSheet, Image, ScrollView, Dimensions} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
let screenWidth = Dimensions.get('window').width
export default class App extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View>
        <Card>
          <ScrollView 
            horizontal = {true}
            pagingEnabled = {true}>
           <View style={styles.imagemContainer}>
            <Image style={styles.imagem} source={require        ('./assets/fotos/MARAGOGI-BANHISTAS.png')} />
           </View>
           <View style={styles.imagemContainer}>
            <Image style={styles.imagem} source={require        ('./assets/fotos/MARAGOGI-COQUEIROS.jpg')} />
           </View>
           <View style={styles.imagemContainer}>
            <Image style={styles.imagem} source={require        ('./assets/fotos/MARAGOGI-MERGULHO.jpg')} />
           </View>
           <View style={styles.imagemContainer}>
            <Image style={styles.imagem} source={require        ('./assets/fotos/MARAGOGI-ORLA.png')} />
           </View>
          </ScrollView>
        </Card>
        </View>
        <View style={styles.legendaContainer}>
          <View style={styles.local}>
            <View>
              <Text style={styles.lugarTexto}>Praia de Maragogi</Text>
            </View>
            <View>
              <Text style={styles.cidadeTexto}>Maragogi - Alagoas, Brasil</Text>
            </View>
          </View>
          <View style={styles.avaliacao}>
            <View style={styles.quadro}>
              <Image style={styles.icone} source={require('./assets/icons/estrela.png')}/>
            </View>
            <View style={styles.quadro}>
              <View>
                <Text style={styles.lugarTexto}>182.548</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.funcoes}>
          <View style={styles.botao}>
            <Image style={styles.iconeGrande} source={require('./assets/icons/003-ligar.png')}/>
          </View>
          <View style={styles.botao}>
          <Image style={styles.iconeGrande} source={require('./assets/icons/001-track.png')}/>
          </View>
          <View style={styles.botao}>
          <Image style={styles.iconeGrande} source={require('./assets/icons/002-compartilhar.png')}/>
          </View>
        </View>
        <View style={styles.resenhaContainer}>
          <Text style={styles.resenhaTexto}>
          Maragogi é uma cidade turística na costa do Oceano Atlântico, no leste do Brasil. É conhecida pelas suas longas praias como Burgalhau, perto do Rio dos Paus. Os recifes de coral ao largo da costa e os bancos de areia criaram uma lagoa pouco profunda, que serve de piscina natural. A sul de Maragogi encontra-se São Bento, uma aldeia piscatória com uma praia repleta de palmeiras. Aqui, a costa faz parte da área protegida da Costa dos Corais, que é rica em flora e fauna.
          </Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 5,
  },
  imagemContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 180,
    width: screenWidth -10,
    marginTop: 2,
  },
  imagem: {
    height: '100%',
    width: '100%',
  },
  legendaContainer: {
    //borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    textAlign: 'center',
  },
  local: {
   // borderWidth: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 5,
  },
  lugarTexto: {
    justifyContent: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
    padding: 3,
    paddingBottom: 0,
    width: 200,
  },
  cidadeTexto: {
    justifyContent: 'center',
    fontSize: 14,
    color: 'grey',
    textAlign: 'justify',
    padding: 2,
    paddingTop: 0,
  },
  avaliacao:{
    //borderWidth: 1,
    width: 90,
    flexDirection:'row',
    alignContent: 'flex-end',
    padding: 5,
  },
  quadro: {
    justifyContent: 'center',
    textAlign: 'center',
    marginTop: 0,
    height: 30,
    width: 30,
  },
  icone: {
    width:'80%',
    height:'80%',
    resizeMode: 'contain',
    justifyContent: 'center',
    margin: 3,
  },
  iconeGrande: {
    width:32,
    height:32,
    resizeMode: 'contain',
  },
  botao: {
    height: 46,
    width: 46,
    margin: 10,
    paddingHorizontal: 5,
  },
  funcoes: {
    //borderWidth:1,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  resenhaContainer: {
      justifyContent: 'flex-start',
      //borderWidth: 1,
  },
  resenhaTexto: {
    padding:10,
    paddingTop: 0,
    textAlign: 'justify',
    fontFamily: 'Arial',
    fontSize: 14,
  }
});

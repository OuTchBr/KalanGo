import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 5,
  },
  imagemContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 160,
    marginTop: 2,
  },
  imagem: {
    height: '100%',
    width: '100%',
  },
  legendaContainer: {
    //borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    textAlign: 'center',
  },
  local: {
   // borderWidth: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 5,
  },
  lugarTexto: {
    justifyContent: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
    padding: 3,
    paddingBottom: 0,
    width: 200,
  },
  cidadeTexto: {
    justifyContent: 'center',
    fontSize: 14,
    color: 'grey',
    textAlign: 'justify',
    padding: 2,
    paddingTop: 0,
  },
  avaliacao:{
    //borderWidth: 1,
    width: 90,
    flexDirection:'row',
    alignContent: 'flex-end',
    padding: 5,
  },
  quadro: {
    justifyContent: 'center',
    textAlign: 'center',
    marginTop: 0,
    height: 30,
    width: 30,
  },
  icone: {
    width:'80%',
    height:'80%',
    resizeMode: 'contain',
    justifyContent: 'center',
    margin: 3,
  },
  iconeGrande: {
    width:32,
    height:32,
    resizeMode: 'contain',
  },
  botao: {
    height: 46,
    width: 46,
    margin: 10,
    paddingHorizontal: 5,
  },
  funcoes: {
    //borderWidth:1,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  resenhaContainer: {
      justifyContent: 'flex-start',
      //borderWidth: 1,
  },
  resenhaTexto: {
    padding:10,
    paddingTop: 0,
    textAlign: 'justify',
    fontFamily: 'Arial',
    fontSize: 14,
  }
});